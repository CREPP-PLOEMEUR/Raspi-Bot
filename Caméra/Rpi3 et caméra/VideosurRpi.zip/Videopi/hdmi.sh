#!/bin/bash
raspivid -t 300000 -h 240 -w 360 -fps 25